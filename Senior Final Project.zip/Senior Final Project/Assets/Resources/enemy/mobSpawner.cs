﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mobSpawner : MonoBehaviour
{


    private Vector3 mobSpawnerPosition;
    float currentTime;
    float spawnTime;
    List<int> enemiesToSpawn;
    public int enemiesLeft;
    int spawnNumber;


    //brb figuring out to approach this


    public void SpawnEnemy(int spawnNum)
    {


        int i = enemiesToSpawn[spawnNum];
        if(i == 1)
        {
          GameObject enemySpawned= (GameObject)Instantiate(Resources.Load("enemy/testEnemy"));
          enemySpawned.name = "testEnemy";
          enemySpawned.layer = 2;
          enemySpawned.transform.position = mobSpawnerPosition;
          enemySpawned.GetComponent<Rigidbody2D>().velocity = new Vector2(500f, 0f);
        }
        else if (i == 2)
        {
          GameObject enemySpawned= (GameObject)Instantiate(Resources.Load("enemy/slimeEnemy"));
          enemySpawned.name = "slimeEnemy";
          enemySpawned.layer = 2;
          enemySpawned.transform.position = mobSpawnerPosition;
          enemySpawned.GetComponent<Rigidbody2D>().velocity = new Vector2(500f, 0f);
        }
        else if (i == 3){
          GameObject enemySpawned= (GameObject)Instantiate(Resources.Load("enemy/wolfEnemy"));
          enemySpawned.name = "wolfEnemy";
          enemySpawned.layer = 2;
          enemySpawned.transform.position = mobSpawnerPosition;
          enemySpawned.GetComponent<Rigidbody2D>().velocity = new Vector2(500f, 0f);
        }
        spawnNumber++;
      }




    // Start is called before the first frame update

    void Start()
    {

      mobSpawnerPosition = GameObject.Find("enemySpawner").GetComponent<Transform>().position;
      RoundsCounter.ChangeRoundNumber();
      enemiesLeft = RoundsCounter.UpdateEnemiesCount();
      enemiesToSpawn = RoundsCounter.CreateEnemyList();
      spawnTime = 1.5f;
      spawnNumber = 0;

      //InvokeRepeating("SpawnEnemy", 3f, 1f);





    }

    public void InitializeEnemiesList()
    {

      RoundsCounter.IncrementRound();

      enemiesToSpawn = RoundsCounter.CreateEnemyList();
      enemiesLeft = RoundsCounter.UpdateEnemiesCount();
      spawnNumber = 0;
    }

    // Update is called once per frame
    void Update()
    {

      currentTime += Time.deltaTime;
      if(currentTime > spawnTime)
      {
        if(enemiesToSpawn.Count > spawnNumber)
        {
          SpawnEnemy(spawnNumber);
        }
        if(enemiesLeft == 0)
        {

          InitializeEnemiesList();


        }
        currentTime = 0;

      }
      //Time variable updated every update, onve above a threshold set to 0 after action done.

    }



}
