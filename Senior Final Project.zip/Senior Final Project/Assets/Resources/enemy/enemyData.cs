﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyData : MonoBehaviour
{
    private int health = 25;
    int enemyDamage = 5;
    int enemyExp = 5;

    private playerArea playerAreaRef;
    private spellList SpellDamageRef;
    private SpellCastingReference SpellCastingRef;
    private Rigidbody2D enemyRbRef;
    private mobSpawner spawnerCountRef;
    private GameObject enemy;

    private IcePillar icePillarRef;

    public Vector2 enemySpeed;
    public float enemySpawnRate;

    float currentTime;
    float ouchieTime;
    bool inPlayerArea;
    bool inObstacleArea;

    private void OnTriggerEnter2D(Collider2D other)
    {



      if(other.gameObject.tag == "Spell")
      {

        if(other.gameObject.name == "Ice Pillar")
        {


          icePillarRef = other.gameObject.GetComponent<IcePillar>();
          inObstacleArea = true;
          ouchieTime = 1f;
          currentTime = 0;

        }
        int damage = SpellCastingRef.FindDamage(other.gameObject.name);
        health -= damage;
        //Debug.Log("You got hit!" + other.gameObject.GetInstanceID());
      }
      else if (other.gameObject.tag == "PlayerArea")
      {

        inPlayerArea = true;
        currentTime = 0;
        ouchieTime = 1f;

      }
      else if(other.gameObject.tag == "GridTile")
      {

        //Pathing if needed

      }




    }
    // Start is called before the first frame update
    void Start()
    {

      playerAreaRef = GameObject.Find("playerArea").GetComponent<playerArea>();
      SpellDamageRef = GameObject.Find("listOfSpells").GetComponent<spellList>();
      SpellCastingRef = GameObject.Find("SpellCasterObj").GetComponent<SpellCastingReference>();
      spawnerCountRef = GameObject.Find("enemySpawner").GetComponent<mobSpawner>();
      inPlayerArea = false;


    }

    // Update is called once per frame
    void Update()
    {
      currentTime += Time.deltaTime;
      if(health <= 0)
      {
        spawnerCountRef.enemiesLeft--;
        playerAreaRef.exp += enemyExp;
        Destroy(this.gameObject);

      }
      if(currentTime > ouchieTime && inPlayerArea == true)
      {
          playerAreaRef.health -= enemyDamage;
          currentTime = 0;
      }

      if(currentTime > ouchieTime && inObstacleArea == true)
      {
          icePillarRef.health -= enemyDamage;
          currentTime = 0;
      }


    }
}
