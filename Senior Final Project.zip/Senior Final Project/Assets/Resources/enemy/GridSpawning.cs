﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridSpawning : MonoBehaviour
{


  private Vector3 lane1Spawn;
  private Vector3 lane2Spawn;
  private Vector3 lane3Spawn;
  private Vector3 lane4Spawn;
  private Vector3 lane5Spawn;
  private Vector3 LastSpawnPos;
  private Random rand = new Random();
  List<Vector3> spawnLocations = new List<Vector3>();





  private void OnTriggerEnter2D(Collider2D other)
  {

    if(other.gameObject.tag == "Enemy")
    {

      other.gameObject.transform.position = SpawnCheckEnemy();
      other.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0f , -100f);


    }

  }



  public Vector3 SpawnCheckEnemy()
  {

    bool correctSpawn = false;


    while(correctSpawn == false)
    {
         int randomNum = UnityEngine.Random.Range(0, 5);
         Vector3 newSpawn = spawnLocations[randomNum];
         if(newSpawn != LastSpawnPos)
         {
              //instantiate the enemy at newSpawn
              LastSpawnPos = newSpawn;
              correctSpawn = true;
              return newSpawn;
         }

     }

     return new Vector3(0,0,0);

  }



    // Start is called before the first frame update
    void Start()
    {


      lane1Spawn = new GameObject().transform.position;
      lane2Spawn = new GameObject().transform.position;
      lane3Spawn = new GameObject().transform.position;
      lane4Spawn = new GameObject().transform.position;
      lane5Spawn = new GameObject().transform.position;


      lane1Spawn = new Vector3(-5,100,-2);;
      spawnLocations.Add(lane1Spawn);

      lane2Spawn = new Vector3(145,100,-2);
      spawnLocations.Add(lane2Spawn);

      lane3Spawn = new Vector3(295,100,-2);
      spawnLocations.Add(lane3Spawn);

      lane4Spawn  = new Vector3(445,100,-2);
      spawnLocations.Add(lane4Spawn);

      lane5Spawn = new Vector3(595,100,-2);
      spawnLocations.Add(lane5Spawn);

      LastSpawnPos = lane1Spawn;


    }

    // Update is called once per frame
    void Update()
    {

    }
}
