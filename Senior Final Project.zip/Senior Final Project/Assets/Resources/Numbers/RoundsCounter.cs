﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public class RoundsCounter : MonoBehaviour
{

    public static int RoundNumber {get; set;}

    private static int enemyType1Count;
    private static int enemyType2Count;
    private static int enemyType3Count;
    private static int enemyType4Count;
    private static int enemyType5Count;
    private static int enemiesInRound;

    private static double calculationType1Count;
    private static double calculationType2Count;
    private static double calculationType3Count;
    private static double calculationType4Count;
    private static double calculationType5Count;

    private static List<Sprite> numberSprites = new List<Sprite>();
    static SpriteRenderer roundCounterRef;
    static SpriteRenderer roundCounterTensRef;

    static Sprite numberZero;
    static Sprite numberOne;
    static Sprite numberTwo;
    static Sprite numberThree;
    static Sprite numberFour;
    static Sprite numberFive;
    static Sprite numberSix;
    static Sprite numberSeven;
    static Sprite numberEight;
    static Sprite numberNine;

    static float currentTime;
    static float spawnTime;

    public static void Initialize()
    {

         RoundNumber = 1;
         //Debug.Log(RoundNumber);

         enemyType1Count = 10; //base enemy
         enemyType2Count = 2; //slimes
         enemyType3Count = 1;
         enemyType4Count = 0;
         enemyType5Count = 0;
         enemiesInRound = enemyType1Count + enemyType2Count + enemyType3Count+ enemyType4Count + enemyType5Count;

         roundCounterRef = GameObject.Find("roundCounter").GetComponent<SpriteRenderer>();
         roundCounterTensRef = GameObject.Find("roundCounterTens").GetComponent<SpriteRenderer>();

         numberZero = Resources.Load<Sprite>("Numbers/Number0");
         numberOne = Resources.Load<Sprite>("Numbers/Number1");
         numberTwo = Resources.Load<Sprite>("Numbers/Number2");
         numberThree = Resources.Load<Sprite>("Numbers/Number3");
         numberFour = Resources.Load<Sprite>("Numbers/Number4");
         numberFive = Resources.Load<Sprite>("Numbers/Number5");
         numberSix = Resources.Load<Sprite>("Numbers/Number6");
         numberSeven = Resources.Load<Sprite>("Numbers/Number7");
         numberEight = Resources.Load<Sprite>("Numbers/Number8");
         numberNine = Resources.Load<Sprite>("Numbers/Number9");

         numberSprites.Add(numberZero);
         numberSprites.Add(numberOne);
         numberSprites.Add(numberTwo);
         numberSprites.Add(numberThree);
         numberSprites.Add(numberFour);
         numberSprites.Add(numberFive);
         numberSprites.Add(numberSix);
         numberSprites.Add(numberSeven);
         numberSprites.Add(numberEight);
         numberSprites.Add(numberNine);



    }

    public static  void PrepareToIncrement()
    {
          calculationType1Count = enemyType1Count;
          calculationType2Count = enemyType2Count;
          calculationType3Count = enemyType3Count;
          //calculationType4Count = enemyType4Count;
          //calculationType5Count = enemyType5Count;

    }//end method

    public static  void Increment()
    {

         calculationType1Count = Math.Round((double)((1.35*RoundNumber)+10) + 5*RoundNumber);
         calculationType2Count = Math.Round((double)((1.2*RoundNumber)+7) + 3*RoundNumber);
         calculationType3Count = Math.Round((double)((1.1*RoundNumber)+7) + 2*RoundNumber);
         //calculationType4Count = Math.Round((double)((RoundNumber)+4) + 1.5*RoundNumber);
         //calculationType5Count = Math.Round((double)RoundNumber+RoundNumber);

         enemyType1Count = (int)calculationType1Count;
         enemyType2Count = (int)calculationType2Count;
         enemyType3Count = (int)calculationType3Count;
         //enemyType4Count = (int)calculationType4Count;
        // enemyType5Count = (int)calculationType5Count;

    }


    public static  void IncrementRound()
    {

      RoundNumber++;
      //Debug.Log("Updated round:" + RoundNumber);
      ChangeRoundNumber();
      //Debug.Log("Number of test enemy: " + enemyType1Count);
      //Debug.Log("Number of slime: " + enemyType2Count);

    }

    public static  void ChangeRoundNumber()
    {

      if(RoundNumber != 1)
      {
        PrepareToIncrement();
        Increment();
      }

      if(RoundNumber < 10)
      {
            roundCounterTensRef.sprite = numberSprites[0];
            roundCounterRef.sprite = numberSprites[RoundNumber];

      }
      else if(RoundNumber > 9)
      {


        int tens = Convert.ToInt32((RoundNumber.ToString())[0].ToString());
        int ones = Convert.ToInt32((RoundNumber.ToString())[1].ToString());
        roundCounterTensRef.sprite = numberSprites[tens];
        roundCounterRef.sprite = numberSprites[ones];

      }


    }


  public static  List<int> CreateEnemyList()
    {
      UpdateEnemiesCount();
      List<int> enemiesToSpawn = new List<int>();
      for (int i=0; i < enemyType1Count; i++)
      {
        enemiesToSpawn.Add(1);
        //Debug.Log("added a base enemy" + (i+1));
      }
      for (int i=0; i < enemyType2Count; i++)
      {
        enemiesToSpawn.Add(2);
        //Debug.Log("added a slime" + (i+1));
      }
      for (int i=0; i < enemyType3Count; i++)
      {
        enemiesToSpawn.Add(3);
        //Debug.Log("added a slime" + (i+1));
      }

      //put other enemy types here once htye exist.
      return enemiesToSpawn;
    }


    public static int UpdateEnemiesCount()
    {
      enemiesInRound = enemyType1Count + enemyType2Count + enemyType3Count+ enemyType4Count + enemyType5Count;
      return enemiesInRound;
    }

    // Start is called before the first frame update
    void Awake()
    {

      Initialize();



    }

    // Update is called once per frame
    void Update()
    {




    }


}
