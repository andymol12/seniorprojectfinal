﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Spell
{
  Empty,
  LightningLance,
  BallLightning,
  FireBall,
  FireWall,
  WaterJet,
  IcePillar,
  SlipperySlope
};

public class SpellButtonInfo : MonoBehaviour
{

    public Dictionary<GameObject, Spell> _spellSlot;


    public GameObject SpellButtonOne;

    public Spell equippedSpellOne = Spell.Empty;

    public GameObject SpellButtonTwo;

    public Spell equippedSpellTwo = Spell.Empty;

    public GameObject SpellButtonThree;

    public Spell equippedSpellThree = Spell.Empty;

    public GameObject SpellButtonFour;

    public Spell equippedSpellFour = Spell.Empty;

    public GameObject SpellButtonFive;

    public Spell equippedSpellFive = Spell.Empty;


     private List<GameObject> _spellButtons = new List<GameObject>();


    // Start is called before the first frame update
    void Start()
    {

      _spellSlot = new Dictionary<GameObject, Spell>();
      SpellButtonOne = GameObject.Find("SpellButtonOneUI");
      SpellButtonTwo = GameObject.Find("SpellButtonTwoUI");
      SpellButtonThree = GameObject.Find("SpellButtonThreeUI");
      SpellButtonFour = GameObject.Find("SpellButtonFourUI");
      SpellButtonFive = GameObject.Find("SpellButtonFiveUI");

      _spellSlot.Add(SpellButtonOne, equippedSpellOne);
      _spellSlot.Add(SpellButtonTwo, equippedSpellTwo);
      _spellSlot.Add(SpellButtonThree, equippedSpellThree);
      _spellSlot.Add(SpellButtonFour, equippedSpellFour);
      _spellSlot.Add(SpellButtonFive, equippedSpellFive);

      _spellButtons.Add(SpellButtonOne);
      _spellButtons.Add(SpellButtonTwo);
      _spellButtons.Add(SpellButtonThree);
      _spellButtons.Add(SpellButtonFour);
      _spellButtons.Add(SpellButtonFive);

    }

    // Update is called once per frame
    void Update()
    {

    }


    public string getSpellType(GameObject button)
    {


      foreach(KeyValuePair<GameObject, Spell> kvp in _spellSlot)
      {
        if(button == kvp.Key)
        {
          return  kvp.Value.ToString();
        }
      }

      return "Empty123";

    }

    public void SwitchSpellSlot(string spellName, int buttonNumber)
    {

         if(spellName == "Lightning Lance")
         {

              _spellSlot[_spellButtons[buttonNumber]] = Spell.LightningLance;
              UpdateCurrentSpell();


         }
         else if(spellName == "Ball Lightning")
         {

              _spellSlot[_spellButtons[buttonNumber]] = Spell.BallLightning;
              UpdateCurrentSpell();

         }
         else if(spellName == "Fire Ball")
         {
              _spellSlot[_spellButtons[buttonNumber]] = Spell.FireBall;
              UpdateCurrentSpell();
         }
         else if(spellName == "Fire Wall")
         {
              _spellSlot[_spellButtons[buttonNumber]] = Spell.FireWall;
              UpdateCurrentSpell();
         }
         else if(spellName == "Ice Pillar")
         {
              _spellSlot[_spellButtons[buttonNumber]] = Spell.IcePillar;
              UpdateCurrentSpell();
         }
         else if(spellName == "Water Jet")
         {
              _spellSlot[_spellButtons[buttonNumber]] = Spell.WaterJet;
              UpdateCurrentSpell();
         }
         else if(spellName == "Empty")
         {
           _spellSlot[_spellButtons[buttonNumber]] = Spell.Empty;
           UpdateCurrentSpell();
        }
        
         Debug.Log("********************************");
         Debug.Log("Spell Slot 1: " + equippedSpellOne);
         Debug.Log("Spell Slot 2: " + equippedSpellTwo);
         Debug.Log("Spell Slot 3: " + equippedSpellThree);
         Debug.Log("Spell Slot 4: " + equippedSpellFour);
         Debug.Log("Spell Slot 5: " + equippedSpellFive);

    }

    private void UpdateCurrentSpell()
    {

      equippedSpellOne = _spellSlot[SpellButtonOne];
      equippedSpellTwo = _spellSlot[SpellButtonTwo];
      equippedSpellThree = _spellSlot[SpellButtonThree];
      equippedSpellFour = _spellSlot[SpellButtonFour];
      equippedSpellFive = _spellSlot[SpellButtonFive];

    }


}
