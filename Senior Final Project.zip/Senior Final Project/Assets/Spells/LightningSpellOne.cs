﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class LightningSpellOne : MonoBehaviour
{
    [System.NonSerialized]
    public int damage = 10;

    [System.NonSerialized]
    public int mana = 5;



    public void CastSpell(Vector3 position)
    {

      GameObject lightningObject = (GameObject)Instantiate(Resources.Load("Lightning Lance"));
      lightningObject.name = "Lightning Lance";
      lightningObject.transform.position = position;
      Destroy(lightningObject, 0.75f);


    }





}
