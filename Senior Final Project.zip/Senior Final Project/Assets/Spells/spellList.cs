﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spellList : MonoBehaviour
{
    // OBSOLETE CLASS

    // READ ABOVE

    // KEEPING FOR THIS RIGHT NOW BECAUSE WE ARE SCARED TO DELETE


   Dictionary<string,int> listOfSpells;
   SpellCastingReference spellRef;


   public int CheckSpell(string spellCast)
   {

     foreach(KeyValuePair<string, int> kvp in listOfSpells)
     {

       if(kvp.Key == spellCast)
       {
         return kvp.Value;
       }

     }

     return 0;

   }
    // Start is called before the first frame update
    void Start()
    {

      spellRef = GameObject.Find("SpellCasterObj").GetComponent<SpellCastingReference>();
      listOfSpells = new Dictionary<string,int>(){
        {"Lightning Lance", 400},
        {"", 10}
      };


      //Debug.Log("listOfSpells count:" + listOfSpells.Count);

    }

    // Update is called once per frame
    void Update()
    {

    }
}
