using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;
using System.Collections.Generic;
//using UnityEngine.CoreModule;



public class Upgrade : MonoBehaviour
{
     public GameObject upgradeUI;

     public Text skillPointsText;
     public LightningSpellOne LightningLanceRef;
     public BallLightning BallLightningRef;
     public FireBall FireBallRef;
     public FireWall FireWallRef;
     public WaterJet WaterJetRef;
     public SlipperySlope SlipperySlopeRef;
     public IcePillar IcePillarRef;
     SpellCastingReference spellRef;
     Button UButtonLightningLance;
     Button UButtonBallLightning;
     Button UButtonFireBall;
     Button UButtonFireWall;
     Button UButtonSlipperySlope;
     Button UButtonWaterJet;
     Button UButtonIcePillar;
     List<Button> buttons;
     bool inUpgradeMenu;

     bool buttonsEnabled;


     public int SkillPoints;

      Dropdown dropdown1;
      Dropdown dropdown2;
      Dropdown dropdown3;
      Dropdown dropdown4;
      Dropdown dropdown5;

      SpellButtonInfo spellButtonInfoRef;

     void Start()
     {

          LightningLanceRef = GameObject.Find("Lightning Lance").GetComponent<LightningSpellOne>();
          BallLightningRef = GameObject.Find("Ball Lightning").GetComponent<BallLightning>();
          FireBallRef = GameObject.Find("Fire Ball").GetComponent<FireBall>();
          FireWallRef = GameObject.Find("Fire Wall").GetComponent<FireWall>();
          WaterJetRef = GameObject.Find("Water Jet").GetComponent<WaterJet>();
          SlipperySlopeRef = GameObject.Find("Slippery Slope").GetComponent<SlipperySlope>();
          IcePillarRef = GameObject.Find("Ice Pillar").GetComponent<IcePillar>();

          UButtonLightningLance = GameObject.Find("UButtonLightningLance").GetComponent<Button>();
          UButtonBallLightning = GameObject.Find("UButtonBallLightning").GetComponent<Button>();
          UButtonFireBall = GameObject.Find("UButtonFireBall").GetComponent<Button>();
          UButtonFireWall = GameObject.Find("UButtonFireWall").GetComponent<Button>();
          UButtonSlipperySlope = GameObject.Find("UButtonSlipperySlope").GetComponent<Button>();
          UButtonWaterJet = GameObject.Find("UButtonWaterJet").GetComponent<Button>();
          UButtonIcePillar = GameObject.Find("UButtonIcePillar").GetComponent<Button>();

          spellRef = GameObject.Find("SpellCasterObj").GetComponent<SpellCastingReference>();
          skillPointsText = GameObject.Find("SkillPointsText").GetComponent<Text>();

          buttonsEnabled = true;
          inUpgradeMenu = false;

          upgradeUI.SetActive(false);

                                                        //buttons = GameObject.FindGameObjectsWithTag("UpgradeButton");

          buttons = new List<Button>();
          buttons.Add(UButtonLightningLance);
          buttons.Add(UButtonBallLightning);
          buttons.Add(UButtonFireBall);
          buttons.Add(UButtonFireWall);
          buttons.Add(UButtonSlipperySlope);
          buttons.Add(UButtonWaterJet);
          buttons.Add(UButtonIcePillar);



          SkillPoints = 1;

          dropdown1 = GameObject.Find("DropdownSlot1").GetComponent<Dropdown>();
          dropdown2 = GameObject.Find("DropdownSlot2").GetComponent<Dropdown>();
          dropdown3 = GameObject.Find("DropdownSlot3").GetComponent<Dropdown>();
          dropdown4 = GameObject.Find("DropdownSlot4").GetComponent<Dropdown>();
          dropdown5 = GameObject.Find("DropdownSlot5").GetComponent<Dropdown>();

          spellButtonInfoRef = GameObject.Find("SpellButtonOneUI").GetComponent<SpellButtonInfo>();

          dropdown1.onValueChanged.AddListener( delegate{ ValueChanged(dropdown1); });
          dropdown2.onValueChanged.AddListener( delegate{ ValueChanged(dropdown2); });
          dropdown3.onValueChanged.AddListener( delegate{ ValueChanged(dropdown3); });
          dropdown4.onValueChanged.AddListener( delegate{ ValueChanged(dropdown4); });
          dropdown5.onValueChanged.AddListener( delegate{ ValueChanged(dropdown5); });


     }//endstart

     public void LightningLanceUpgrade()
     {

          Debug.Log("clicked buttons:D");
          SkillPoints--;
          LightningLanceRef.damage += 5;
          LightningLanceRef.mana -= 5;
          spellRef.UpdateDamage(LightningLanceRef.gameObject.name, LightningLanceRef.damage);
     }

     public void IcePillarUpgrade()
     {

          Debug.Log("clicked buttons:D");
          SkillPoints--;
          IcePillarRef.health += 200;

     }

     public void BallLightningUpgrade()
     {
          Debug.Log("clicked buttons:D");
          SkillPoints--;
          BallLightningRef.damage += 5;
          BallLightningRef.mana -= 5;
          spellRef.UpdateDamage(BallLightningRef.gameObject.name, BallLightningRef.damage);

     }

     public void FireBallUpgrade()
     {

          SkillPoints--;
          FireBallRef.damage += 5;
          FireBallRef.mana -= 5;
          spellRef.UpdateDamage(FireBallRef.gameObject.name, FireBallRef.damage);
     }

     public void FireWallUpgrade()
     {
          Debug.Log("clicked buttons:D");
          SkillPoints--;
          FireWallRef.damage += 5;
          FireWallRef.mana -= 5;
          spellRef.UpdateDamage(FireWallRef.gameObject.name, FireWallRef.damage);
     }

     public void SlipperySlopeUpgrade()
     {
          Debug.Log("clicked buttons:D");
          SkillPoints--;
          SlipperySlopeRef.damage += 5;
          SlipperySlopeRef.mana -= 5;
          spellRef.UpdateDamage(SlipperySlopeRef.gameObject.name, SlipperySlopeRef.damage);
     }

     public void WaterJetUpgrade()
     {
          Debug.Log("clicked buttons:D");
          SkillPoints--;
          WaterJetRef.damage += 5;
          WaterJetRef.mana -= 5;
          spellRef.UpdateDamage(WaterJetRef.gameObject.name, WaterJetRef.damage);
     }

     public void AddSkillPoint()
     {
          SkillPoints++;
     }

     void EnableDisableButtons()
     {
          if(SkillPoints == 0 && buttonsEnabled == true)
          {
               foreach (Button b in buttons)
               {
                    b.interactable = false;
               }
               buttonsEnabled = false;
          }
          else if (SkillPoints > 0 && buttonsEnabled == false)
          {
               foreach (Button b in buttons)
               {
                    b.interactable = true;
               }
               buttonsEnabled = true;
          }
     }

     void ExitUpgradeMenu()
     {
          upgradeUI.SetActive(false);
          inUpgradeMenu = false;
          Time.timeScale = 1f;
          //send dropdowns to the back :D -80


          dropdown1.transform.position = new Vector3(-200, -200, -100);
          dropdown2.transform.position = new Vector3(-500, -200, -100);
          dropdown3.transform.position = new Vector3(-700,-200, -100);
          dropdown4.transform.position = new Vector3(100,-200, -100);
          dropdown5.transform.position = new Vector3(400,-200, -100);
     }

     void OpenUpgradeMenu()
     {
          upgradeUI.SetActive(true);
          inUpgradeMenu = true;
          Time.timeScale = 0f;

          //bring dropdowns to the front 0
          dropdown1.transform.position = new Vector3(-400,-800,-80);
          dropdown2.transform.position = new Vector3(0,-800,-80);
          dropdown3.transform.position = new Vector3(400,-800,-80);
          dropdown4.transform.position = new Vector3(800,-800,-80);
          dropdown5.transform.position = new Vector3(1200,-800,-80);





     }

     void Update()
     {
          skillPointsText.text = ("Skill points: " + SkillPoints);
          if(Input.GetKeyDown(KeyCode.Escape))
          {
               if(inUpgradeMenu == false)
               {
                    OpenUpgradeMenu();
               }
               else if (inUpgradeMenu == true)
               {
                    ExitUpgradeMenu();
               }
          }

          EnableDisableButtons();

     }

     public void ValueChanged(Dropdown dropdownX)
      {
        if(dropdownX == dropdown1)
        {
          string slot1 = dropdown1.options[dropdownX.value].text;
          spellButtonInfoRef.SwitchSpellSlot(slot1, 0);
        }
        else if(dropdownX == dropdown2)
        {
          string slot2 = dropdown2.options[dropdownX.value].text;
          spellButtonInfoRef.SwitchSpellSlot(slot2, 1);
        }
        else if(dropdownX == dropdown3)
        {
          string slot3 = dropdown3.options[dropdownX.value].text;
          spellButtonInfoRef.SwitchSpellSlot(slot3, 2);
        }
        else if(dropdownX == dropdown4)
        {
          string slot4 = dropdown4.options[dropdownX.value].text;
          spellButtonInfoRef.SwitchSpellSlot(slot4, 3);
        }
        else if(dropdownX == dropdown5)
        {
          string slot5 = dropdown5.options[dropdownX.value].text;

           spellButtonInfoRef.SwitchSpellSlot(slot5, 4);
        }



      }//end method
}
