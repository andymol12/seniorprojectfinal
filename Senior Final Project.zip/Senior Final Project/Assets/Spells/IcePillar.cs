﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IcePillar : MonoBehaviour
{

  [System.NonSerialized]
  public int health = 20;

  [System.NonSerialized]
  public int mana = 20;

  public Dictionary<Collider2D, Vector2> listOfStoppedEnemies;

    // Start is called before the first frame update
    void Start()
    {


      listOfStoppedEnemies = new Dictionary<Collider2D, Vector2>();

    }



    // Update is called once per frame
    void Update()
    {
      if(health <= 0)
      {
        foreach(KeyValuePair<Collider2D, Vector2> kvp in listOfStoppedEnemies)
        {
          kvp.Key.gameObject.GetComponent<Rigidbody2D>().velocity = kvp.Value;
        }
        Destroy(this.gameObject);
      }


    }

    public void CastSpell(Vector3 position)
    {

      GameObject IcePillarObj = (GameObject)Instantiate(Resources.Load("Ice Pillar"));
      IcePillarObj.name = "Ice Pillar";
      IcePillarObj.transform.position = position;


    }

    public void OnTriggerEnter2D(Collider2D other)
    {

      Debug.Log("Something entered me");
      listOfStoppedEnemies.Add(other, other.gameObject.GetComponent<Rigidbody2D>().velocity);
      other.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0,0);

    }





}
