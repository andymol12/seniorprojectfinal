﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpellCastingReference : MonoBehaviour
{
  private Grid GridRef;
  public LightningSpellOne LightningLanceRef;
  public BallLightning BallLightningRef;
  public FireBall FireBallRef;
  public FireWall FireWallRef;
  public WaterJet WaterJetRef;
  public SlipperySlope SlipperySlopeRef;
  public IcePillar IcePillarRef;
  public playerArea player;
  Dictionary<string , int> listOfSpells;

    void Start()
    {

      GridRef = GameObject.Find("Grid").GetComponent<Grid>();
      LightningLanceRef = GameObject.Find("Lightning Lance").GetComponent<LightningSpellOne>();
      BallLightningRef = GameObject.Find("Ball Lightning").GetComponent<BallLightning>();
      FireBallRef = GameObject.Find("Fire Ball").GetComponent<FireBall>();
      FireWallRef = GameObject.Find("Fire Wall").GetComponent<FireWall>();
      WaterJetRef = GameObject.Find("Water Jet").GetComponent<WaterJet>();
      SlipperySlopeRef = GameObject.Find("Slippery Slope").GetComponent<SlipperySlope>();
      IcePillarRef = GameObject.Find("Ice Pillar").GetComponent<IcePillar>();

      player = GameObject.Find("playerArea").GetComponent<playerArea>();





      listOfSpells = new Dictionary<string,int>(){
        {"Lightning Lance", LightningLanceRef.damage},
        {"Ice Pillar" , 0},
        {"FireBall", FireBallRef.damage}

      };




    }

    // Update is called once per frame
    void Update()
    {

    }

    public void UpdateDamage(string spellName, int newDamage)
    {

      listOfSpells[spellName] = newDamage;

    }



    public int FindDamage(string spellName)
    {

        //Debug.Log("Here is your H O P E: " + LightningLanceRef.damage);
        foreach(KeyValuePair<string, int> kvp in listOfSpells)
        {

          if(kvp.Key == spellName)
          {

            return kvp.Value;

          }

        }
        return 0;

    }

    public void FindCorrectCast(string spellName, GameObject tile)
    {
      if(spellName == "LightningLance")
      {

        Vector3 position = tile.transform.position;
        position.y = GridRef.wholeGrid[0,2].transform.position.y;
        position.z = -2;
        if(player.mana >= LightningLanceRef.mana)
        {
          LightningLanceRef.CastSpell(position);
          player.mana -= LightningLanceRef.mana;

        }
        else
        {
          Debug.Log("Not enough mana!");
        }



      }
      else if (spellName == "IcePillar")
      {
        Vector3 position = tile.transform.position;
        position.z = -2;
        if(player.mana >= IcePillarRef.mana)
        {
          IcePillarRef.CastSpell(position);
          player.mana -= IcePillarRef.mana;

        }
      }
      else if(spellName == "BallLightning")
      {

      }
      else if(spellName == "FireBall")
      {
        Vector3 position = tile.transform.position;
        position.y = GridRef.wholeGrid[0,4].transform.position.y;
        position.z = -2;
        if(player.mana >= FireBallRef.mana)
        {
          FireBallRef.CastSpell(position);
          player.mana -= FireBallRef.mana;

        }
      }
      else if(spellName == "FireWall")
      {

      }
      else if(spellName == "WaterJet")
      {

      }
      else if(spellName == "SlipperySlope")
      {

      }
    }
}
