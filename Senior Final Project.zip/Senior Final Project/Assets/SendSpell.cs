﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SendSpell : MonoBehaviour
{



    // OBSOLETE CLASS

    // READ ABOVE

    // KEEPING FOR THIS RIGHT NOW BECAUSE WE ARE SCARED TO DELETE


    private string selectedSpell = "";
    private Grid GridRef;


    public void sendSpellToCast()
    {


  				//GameObject detectedTile = detected.collider.GetComponent<GameObject>();
          //GridRef.currentlySelectedSpell = GameObject.Find("spellButtonOne").tag;
          //Debug.Log("sent the shit :D");

    }



}
