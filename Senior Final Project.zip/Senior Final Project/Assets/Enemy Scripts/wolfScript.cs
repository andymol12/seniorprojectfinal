﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class wolfScript : MonoBehaviour
{
  private int health = 20;
  int enemyDamage = 2;
  int enemyExp = 5;

  private playerArea playerAreaRef;
  private spellList SpellDamageRef;
  private SpellCastingReference SpellCastingRef;
  private Rigidbody2D enemyRbRef;
  private mobSpawner spawnerCountRef;
  private GameObject enemy;

  public Vector2 enemySpeed;
  public float enemySpawnRate;


  private IcePillar icePillarRef;


  float currentTime;
  float ouchieTime;
  bool inPlayerArea;
  bool firstPathDone;
  bool inObstacleArea;


  Vector2 wolfDirection;

  [System.NonSerialized]
  Dictionary<string,Vector2> wolfPath = new Dictionary<string,Vector2>();

  private void OnTriggerEnter2D(Collider2D other)
  {



    if(other.gameObject.tag == "Spell")
    {

      if(other.gameObject.name == "Ice Pillar")
      {


        icePillarRef = other.gameObject.GetComponent<IcePillar>();
        inObstacleArea = true;
        ouchieTime = 1f;
        currentTime = 0;

      }

      int damage = SpellCastingRef.FindDamage(other.gameObject.name);
      health -= damage;
      //Debug.Log("You got hit!" + other.gameObject.GetInstanceID());
    }
    else if (other.gameObject.tag == "PlayerArea")
    {

      inPlayerArea = true;
      currentTime = 0;
      ouchieTime = 0.2f;

    }
    else if(other.gameObject.tag == "GridTile")
    {

      if(other.gameObject.name == "Grid Object [1],[1]" && firstPathDone == false)
      {

        //Debug.Log("Suck it");

        wolfPath.Add("Grid Object [1],[1]", new Vector2(400, 0f));
        wolfPath.Add("Grid Object [5],[1]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [5],[2]", new Vector2(-400f, 0f));
        wolfPath.Add("Grid Object [1],[2]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [1],[3]", new Vector2(400f, 0f));
        wolfPath.Add("Grid Object [5],[3]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [5],[4]", new Vector2(-400f, 0f));
        wolfPath.Add("Grid Object [1],[4]", new Vector2(0f, -100f));



      }
      else if(other.gameObject.name == "Grid Object [2],[1]" && firstPathDone == false)
      {

        wolfPath.Add("Grid Object [2],[1]", new Vector2(400, 0f));
        wolfPath.Add("Grid Object [5],[1]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [5],[2]", new Vector2(-400f, 0f));
        wolfPath.Add("Grid Object [1],[2]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [1],[3]", new Vector2(400f, 0f));
        wolfPath.Add("Grid Object [5],[3]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [5],[4]", new Vector2(-400f, 0f));
        wolfPath.Add("Grid Object [1],[4]", new Vector2(0f, -100f));

      }
      else if(other.gameObject.name == "Grid Object [3],[1]" && firstPathDone == false)
      {

        wolfPath.Add("Grid Object [3],[1]", new Vector2(400, 0f));
        wolfPath.Add("Grid Object [5],[1]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [5],[2]", new Vector2(-400f, 0f));
        wolfPath.Add("Grid Object [1],[2]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [1],[3]", new Vector2(400f, 0f));
        wolfPath.Add("Grid Object [5],[3]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [5],[4]", new Vector2(-400f, 0f));
        wolfPath.Add("Grid Object [1],[4]", new Vector2(0f, -100f));

      }
      else if(other.gameObject.name == "Grid Object [4],[1]" && firstPathDone == false)
      {

        wolfPath.Add("Grid Object [4],[1]", new Vector2(400, 0f));
        wolfPath.Add("Grid Object [5],[1]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [5],[2]", new Vector2(-400f, 0f));
        wolfPath.Add("Grid Object [1],[2]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [1],[3]", new Vector2(400f, 0f));
        wolfPath.Add("Grid Object [5],[3]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [5],[4]", new Vector2(-400f, 0f));
        wolfPath.Add("Grid Object [1],[4]", new Vector2(0f, -100f));

      }
      else if(other.gameObject.name == "Grid Object [5],[1]" && firstPathDone == false)
      {

        //wolfPath.Add("Grid Object [5],[1]", new Vector2(100, 0f));
        //wolfPath.Add("Grid Object [5],[1]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [5],[2]", new Vector2(-400f, 0f));
        wolfPath.Add("Grid Object [1],[2]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [1],[3]", new Vector2(400f, 0f));
        wolfPath.Add("Grid Object [5],[3]", new Vector2(0f, -100f));
        wolfPath.Add("Grid Object [5],[4]", new Vector2(-400f, 0f));
        wolfPath.Add("Grid Object [1],[4]", new Vector2(0f, -100f));

      }

      firstPathDone = true;
      if(wolfPath.TryGetValue(other.gameObject.name, out wolfDirection))
      {


        this.gameObject.GetComponent<Rigidbody2D>().velocity = wolfDirection;


      }


    }




  }
  // Start is called before the first frame update
  void Start()
  {

    playerAreaRef = GameObject.Find("playerArea").GetComponent<playerArea>();
    SpellDamageRef = GameObject.Find("listOfSpells").GetComponent<spellList>();
    SpellCastingRef = GameObject.Find("SpellCasterObj").GetComponent<SpellCastingReference>();
    spawnerCountRef = GameObject.Find("enemySpawner").GetComponent<mobSpawner>();
    inPlayerArea = false;
    firstPathDone = false;

  }

  // Update is called once per frame
  void Update()
  {
    currentTime += Time.deltaTime;
    if(health <= 0)
    {
      spawnerCountRef.enemiesLeft--;
      playerAreaRef.exp += enemyExp;
      Destroy(this.gameObject);

    }
    if(currentTime > ouchieTime && inPlayerArea == true)
    {
        playerAreaRef.health -= enemyDamage;
        currentTime = 0;
    }

    if(currentTime > ouchieTime && inObstacleArea == true)
    {
        icePillarRef.health -= enemyDamage;
        currentTime = 0;
    }

  }
}
