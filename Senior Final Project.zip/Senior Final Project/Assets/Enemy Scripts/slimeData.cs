﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class slimeData : MonoBehaviour
{


  private int health = 15;
  int enemyDamage = 1;
  int enemyExp = 3;

  private playerArea playerAreaRef;
  private spellList SpellDamageRef;
  private SpellCastingReference SpellCastingRef;
  private Rigidbody2D enemyRbRef;
  private mobSpawner spawnerCountRef;
  private GameObject enemy;

  private IcePillar icePillarRef;

  public Vector2 enemySpeed;
  public float enemySpawnRate;

  float currentTime;
  float ouchieTime;
  bool inPlayerArea;
  bool inObstacleArea;

  Vector2 slimeDirection;


  Dictionary<string,Vector2> slimePath = new Dictionary<string,Vector2>();






  private void OnTriggerEnter2D(Collider2D other)
  {



    if(other.gameObject.tag == "Spell")
    {

      if(other.gameObject.name == "Ice Pillar")
      {


        icePillarRef = other.gameObject.GetComponent<IcePillar>();
        inObstacleArea = true;
        ouchieTime = 1f;
        currentTime = 0;

      }

      int damage = SpellCastingRef.FindDamage(other.gameObject.name);
      health -= damage;



    }
    else if (other.gameObject.tag == "PlayerArea")
    {

      inPlayerArea = true;
      currentTime = 0;
      ouchieTime = 2.5f;

    }
    else if(other.gameObject.tag == "GridTile")
    {


      if(other.gameObject.name == "Grid Object [1],[1]")
      {

        //Debug.Log("Suck it");

        slimePath.Add("Grid Object [1],[1]", new Vector2(0, -100f));
        slimePath.Add("Grid Object [1],[2]", new Vector2(100f, 0f));
        slimePath.Add("Grid Object [2],[2]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [2],[3]", new Vector2(-100f, 0f));
        slimePath.Add("Grid Object [1],[3]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [1],[4]", new Vector2(100f, 0f));
        slimePath.Add("Grid Object [2],[4]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [2],[5]", new Vector2(0f, -100f));



      }
      else if(other.gameObject.name == "Grid Object [2],[1]")
      {

        slimePath.Add("Grid Object [2],[1]", new Vector2(0, -100f));
        slimePath.Add("Grid Object [2],[2]", new Vector2(100f, 0f));
        slimePath.Add("Grid Object [3],[2]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [3],[3]", new Vector2(-100f, 0f));
        slimePath.Add("Grid Object [2],[3]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [2],[4]", new Vector2(100f, 0f));
        slimePath.Add("Grid Object [3],[4]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [3],[5]", new Vector2(0f, -100f));

      }
      else if(other.gameObject.name == "Grid Object [3],[1]")
      {

        slimePath.Add("Grid Object [3],[1]", new Vector2(0, -100f));
        slimePath.Add("Grid Object [3],[2]", new Vector2(100f, 0f));
        slimePath.Add("Grid Object [4],[2]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [4],[3]", new Vector2(-100f, 0f));
        slimePath.Add("Grid Object [3],[3]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [3],[4]", new Vector2(100f, 0f));
        slimePath.Add("Grid Object [4],[4]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [4],[5]", new Vector2(0f, -100f));

      }
      else if(other.gameObject.name == "Grid Object [4],[1]")
      {

        slimePath.Add("Grid Object [4],[1]", new Vector2(0, -100f));
        slimePath.Add("Grid Object [4],[2]", new Vector2(100f, 0f));
        slimePath.Add("Grid Object [5],[2]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [5],[3]", new Vector2(-100f, 0f));
        slimePath.Add("Grid Object [4],[3]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [4],[4]", new Vector2(100f, 0f));
        slimePath.Add("Grid Object [5],[4]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [5],[5]", new Vector2(0f, -100f));

      }
      else if(other.gameObject.name == "Grid Object [5],[1]")
      {

        slimePath.Add("Grid Object [5],[1]", new Vector2(0, -100f));
        slimePath.Add("Grid Object [5],[2]", new Vector2(-100f, 0f));
        slimePath.Add("Grid Object [4],[2]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [4],[3]", new Vector2(100f, 0f));
        slimePath.Add("Grid Object [5],[3]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [5],[4]", new Vector2(-100f, 0f));
        slimePath.Add("Grid Object [4],[4]", new Vector2(0f, -100f));
        slimePath.Add("Grid Object [4],[5]", new Vector2(0f, -100f));

      }

      if(slimePath.TryGetValue(other.gameObject.name, out slimeDirection))
      {


        this.gameObject.GetComponent<Rigidbody2D>().velocity = slimeDirection;


      }



    }




  }
  // Start is called before the first frame update
  void Start()
  {

    playerAreaRef = GameObject.Find("playerArea").GetComponent<playerArea>();
    SpellDamageRef = GameObject.Find("listOfSpells").GetComponent<spellList>();
    spawnerCountRef = GameObject.Find("enemySpawner").GetComponent<mobSpawner>();
    SpellCastingRef = GameObject.Find("SpellCasterObj").GetComponent<SpellCastingReference>();
    inPlayerArea = false;




  }

  // Update is called once per frame
  void Update()
  {

    currentTime += Time.deltaTime;
    if(health <= 0)
    {
      spawnerCountRef.enemiesLeft--;
      playerAreaRef.exp += enemyExp;
      Destroy(this.gameObject);

    }
    if(currentTime > ouchieTime && inPlayerArea == true)
    {
        playerAreaRef.health -= enemyDamage;
        currentTime = 0;
    }

    if(currentTime > ouchieTime && inObstacleArea == true)
    {
        icePillarRef.health -= enemyDamage;
        currentTime = 0;
    }

  }
}
