﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireBall : MonoBehaviour
{
  [System.NonSerialized]
  public int damage = 20;

  [System.NonSerialized]
  public int mana = 10;

  private void OnTriggerEnter2D(Collider2D other)
  {

    Destroy(this.gameObject);

  }

  public void CastSpell(Vector3 position)
  {

    GameObject fireBallObj = (GameObject)Instantiate(Resources.Load("Fire Ball"));
    fireBallObj.name = "FireBall";
    fireBallObj.transform.position = position;
    fireBallObj.GetComponent<Rigidbody2D>().velocity = new Vector2(0, 2000);
    Destroy(fireBallObj, 0.30f);


  }
}
