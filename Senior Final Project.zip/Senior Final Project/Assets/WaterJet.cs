﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaterJet : MonoBehaviour
{
  [System.NonSerialized]
  public int damage = 5;

  [System.NonSerialized]
  public int mana = 8;



  public void CastSpell(Vector3 position)
  {

    //GameObject ballLightningObject = (GameObject)Instantiate(Resources.Load("Lightning Lance"));
    //lightningObject.name = "Lightning Lance";
    //Debug.Log("this is the lightning prefab" + lightningObject);
    //lightningObject.transform.position = position;
    // Destroy(lightningObject, 0.75f);


  }
}
