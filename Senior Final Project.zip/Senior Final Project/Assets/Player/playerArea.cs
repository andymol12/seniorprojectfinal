﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;

public class playerArea : MonoBehaviour
{


    public int maxHealth;
    public int maxMana;

    public int health;
    public int mana;

    public int playerLevel;
    public int exp;
    public int expLevelCap;

    public healthScript healthBar;
    public ManaScript manaBar;
    public ExpScript expBar;
    float currentTime;
    float regenManaTime;
    public Transform gameOverScreen;

    Upgrade upgradeRef;


    private void OnTriggerEnter2D(Collider2D other)
    {

      if(other.gameObject.tag == "Enemy")
      {

        other.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0f , 0f);


      }

    }


    // Start is called before the first frame update
    void Awake()
    {
      maxHealth = 100;
      maxMana = 100;
      health = maxHealth;
      mana = maxMana;
      exp = 0;
      expLevelCap = 25;
      regenManaTime = 2.0f;

      upgradeRef = GameObject.Find("Canvas").GetComponent<Upgrade>();
      gameOverScreen = GameObject.Find("GameOverCanvas").GetComponent<Transform>();
      healthBar = GameObject.Find("HealthBar").GetComponent<healthScript>();
      manaBar = GameObject.Find("ManaBar").GetComponent<ManaScript>();
      expBar = GameObject.Find("ExpBar").GetComponent<ExpScript>();


      healthBar.SetMaxHealth(maxHealth);
      manaBar.SetMaxMana(maxMana);
      expBar.SetMaxExp(expLevelCap);
      //gameOverScreen.position = new Vector3(6,-6,-70);
    }

    // Update is called once per frame
    void Update()
    {

      currentTime += Time.deltaTime;
      if(currentTime > regenManaTime)
      {
        mana += 10;
        currentTime = 0;

      }


      manaBar.SetMana(mana);
      healthBar.SetHealth(health);
      expBar.SetExp(exp);

      if(exp >= expLevelCap)
      {
        LevelUp();
      }
      if(health <= 0)
      {
          gameOverScreen.position = new Vector3(265,-350, 0);


      }

    }

    public void LevelUp()
    {

      exp = 0;
      playerLevel++;
      upgradeRef.SkillPoints += 3;
      expLevelCap += 10;
      expBar.SetMaxExp(expLevelCap);
    }


}
