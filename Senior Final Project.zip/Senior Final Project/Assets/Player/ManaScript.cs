﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ManaScript : MonoBehaviour
{
  public Slider slider;

  public void SetMana(int mana)
  {
    slider.value = mana;
  }

  public void SetMaxMana(int mana)
  {
    
    slider.maxValue = mana;
    slider.value = mana;

  }

  void Start()
  {

    slider = GameObject.Find("ManaBar").GetComponent<Slider>();

  }

}
