﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class healthScript : MonoBehaviour
{
    public Slider slider;

    void Start()
    {

      slider = GameObject.Find("HealthBar").GetComponent<Slider>();

    }

    public void SetHealth(int health)
    {
      slider.value = health;
    }

    public void SetMaxHealth(int maxHealth)
    {

      slider.maxValue = maxHealth;
      slider.value = maxHealth;

    }




}
