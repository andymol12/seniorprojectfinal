﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ExpScript : MonoBehaviour
{
  public Slider slider;

  void Start()
  {

    slider = GameObject.Find("ExpBar").GetComponent<Slider>();

  }

  public void SetExp(int exp)
  {
    slider.value = exp;
  }

  public void SetMaxExp(int maxExp)
  {

    slider.maxValue = maxExp;


  }
}
