﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlipperySlope : MonoBehaviour
{
  [System.NonSerialized]
  public int damage = 20;

  [System.NonSerialized]
  public int mana = 10;



  public void CastSpell(Vector3 position)
  {

    //GameObject ballLightningObject = (GameObject)Instantiate(Resources.Load("Lightning Lance"));
    //lightningObject.name = "Lightning Lance";
    //Debug.Log("this is the lightning prefab" + lightningObject);
    //lightningObject.transform.position = position;
    // Destroy(lightningObject, 0.75f);


  }
}
