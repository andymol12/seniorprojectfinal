﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


enum TerrainEffect
{
     Damage,
     Slow,
     Stun
}

public class GridObject : MonoBehaviour
{
     private int Width = 5;
     private int Height = 5;
     private bool HasObstacle = false;


    // Start is called before the first frame update
     public GridObject()
     {
          Width = 5;
          Height = 5;
          HasObstacle = false;

     }

     void Update()
     {


     }

     public void createObstacle()
     {
          HasObstacle = true;
     }

     public void deleteObstacle()
     {
          HasObstacle = false;
     }

}
