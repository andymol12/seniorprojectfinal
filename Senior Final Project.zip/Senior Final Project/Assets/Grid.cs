using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

enum clickState
{
  NoClick,
  SpellButtonClick,
  GridClick,
  UIClick
}

public class Grid : MonoBehaviour
{

     //Grid Generation
     private int rows = 5;
     private int columns = 5;
     private int size = 150;
     public GameObject[,] wholeGrid = new GameObject[5,5];
     public GameObject[,] spellGrid = new GameObject[5,5];


     //Spell Generation
     private clickState currentClickState = clickState.NoClick;
     public Spell currentlySelectedSpell;
     public GameObject mostRecentSpellTile;
     private LightningSpellOne LightningCast;
     private SpellButtonInfo spellButtonManager;
     private SpellCastingReference spellCasterRef;







     void Start()
    {
      spellCasterRef = GameObject.Find("SpellCasterObj").GetComponent<SpellCastingReference>();
      spellButtonManager = GameObject.Find("SpellButtonOneUI").GetComponent<SpellButtonInfo>();
      GenerateGrid();
      generateSpellGrid();


    }

    // Update is called once per frame
    void Update()
    {

      spellDetection();

    }

    //Mouse Click Stuff
    private void spellDetection()
    {

      if(Input.GetKeyDown("1"))
      {

        mostRecentSpellTile = spellButtonManager.SpellButtonOne;
        currentClickState = clickState.SpellButtonClick;
      }
      else if(Input.GetKeyDown("2"))
      {
        mostRecentSpellTile = spellButtonManager.SpellButtonTwo;
        currentClickState = clickState.SpellButtonClick;
      }
      else if(Input.GetKeyDown("3"))
      {
        mostRecentSpellTile = spellButtonManager.SpellButtonThree;
        currentClickState = clickState.SpellButtonClick;
      }
      else if(Input.GetKeyDown("4"))
      {
        mostRecentSpellTile = spellButtonManager.SpellButtonFour;
        currentClickState = clickState.SpellButtonClick;
      }
      else if(Input.GetKeyDown("5"))
      {
        mostRecentSpellTile = spellButtonManager.SpellButtonFive;
        currentClickState = clickState.SpellButtonClick;
      }

      if (Input.GetMouseButtonDown(0))
      {

        Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 mousePosition2D = new Vector2(mousePosition.x, mousePosition.y);

			  RaycastHit2D detected = Physics2D.Raycast(mousePosition2D, Vector2.zero);

  			if (detected.collider != null)
          {
              GameObject detectedTile = detected.collider.gameObject;
              //Debug.Log(detectedTile.name);
              if(detected.collider.gameObject.tag == "SpellTile" && currentClickState == clickState.SpellButtonClick)
              {
                //Debug.Log("getting here");
                //Debug.Log(spellButtonManager.getSpellType(mostRecentSpellTile), detectedTile);
                spellCast(spellButtonManager.getSpellType(mostRecentSpellTile), detectedTile);
                currentClickState = clickState.GridClick;
                Debug.Log("THIS IS THE MOST" + mostRecentSpellTile);
              }
              else if(detected.collider.gameObject.tag == "GridTile")
              {
                currentClickState = clickState.GridClick;
              }
              else if(detected.collider.gameObject.tag == "SpellButton")
              {
                currentClickState = clickState.SpellButtonClick;
                mostRecentSpellTile = detectedTile;
              }

  		   	}
          else if(detected.collider == null)
          {
            Debug.Log("No meggies");
          }

      }


    }


    //i think because of the nature of lightning lance, there needs to be a special if here to determine it's y poition without needing to pass
    //a reference to the spell casting reference. So imma keep it here but it wont handle CASTING just sending it to be found. Depending on the other
    //spells, we might need special manipulation and then we sent it to spell
    //for those we could probably jus have  a reference to grid. cuz what else could be weird bout it
    //you mean send it WITH a grid reference? no weso wlhalt? ob well yes but aslo more. okay but i guess that it doesnt really matter,
    //cause either way it's passing SOMETHING anyway, it's just
    //how it needs to be also we should keep these comments caause bean will be scaared lol
    private void spellCast(string spell, GameObject tile)
    {

      spellCasterRef.FindCorrectCast(spell, tile);

    }



    private void GenerateGrid()
    {

     //GameObject referenceGO = (GameObject)Instantiate(Resources.Load("pixel3"));
     GameObject referenceGO = (GameObject)Instantiate(Resources.Load("UISprites/gridTile"));
     transform.position = Camera.main.ScreenToWorldPoint( new Vector3(Screen.width/2, Screen.height/2, 0));
         for(int i = 0; i < columns; i++)
         {
              for(int j = 0; j < rows; j++)
              {



                   GameObject tempGO = (GameObject)Instantiate(referenceGO,transform);
                   tempGO.tag = "GridTile";
                   tempGO.layer = 2;
                   tempGO.AddComponent<BoxCollider2D>();

                   float posX = i * size;
                   float posY = j * -size;

                   tempGO.transform.position = new Vector3(posX,posY,0);
                   tempGO.GetComponent<BoxCollider2D>().size = new Vector2(0.45f, 0.45f);
                   tempGO.name = "Grid Object [" + (i + 1) +"],[" + (j + 1) + "]";
                   wholeGrid[i,j] = tempGO;


                }
         }
         Destroy(referenceGO);
       }



       private void generateSpellGrid()
       {
         GameObject referenceGO = (GameObject)Instantiate(Resources.Load("pixel3"));
         transform.position = Camera.main.ScreenToWorldPoint( new Vector3(Screen.width/2, Screen.height/2, -1));
             for(int i = 0; i < columns; i++)
             {
                  for(int j = 0; j < rows; j++)
                  {



                       GameObject tempGO = (GameObject)Instantiate(referenceGO,transform);
                       tempGO.tag = "SpellTile";
                       tempGO.layer = 8;
                       tempGO.AddComponent<BoxCollider2D>();

                       float posX = i * size;
                       float posY = j * -size;

                       tempGO.transform.position = new Vector3(posX,posY,0);
                       tempGO.GetComponent<BoxCollider2D>().size = new Vector2(2.5f, 2.5f);
                       tempGO.name = "Spell Grid [" + (i + 1) +"],[" + (j + 1) + "]";
                       spellGrid[i,j] = tempGO;


                    }
             }
             Destroy(referenceGO);
       }

}
